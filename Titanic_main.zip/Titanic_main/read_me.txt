-------------------------------------------------------------------------------------------------------------------------------------------
Number of Files provided 
-------------------------------------------------------------------------------------------------------------------------------------------
1) Titanic_main.ipynb
2) submission_main.csv (It is an output file which is used to submit our predictions in Kaggle ceompetition)  
3) read_me


-------------------------------------------------------------------------------------------------------------------------------------------
Different Imports required to run Ipynb file in your System
-------------------------------------------------------------------------------------------------------------------------------------------
1) A good Computing System
2) should have jupyter notebook installed in your system 
3) Open Command Prompt and run Jupyter Notebook
4) open the Titanic_main.ipynb using the local server 
5) Click on each cell and press Shift+Enter to run the code in the cell
6) make sure all the import files mentioned below are installed in your system

import tensorflow as tf
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import Imputer
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import LabelBinarizer
from sklearn.model_selection import train_test_split
from collections import namedtuple
from sklearn.preprocessing import Binarizer
plt.rcParams['patch.force_edgecolor'] = True
plt.rcParams['grid.color'] = 'k'
plt.rcParams['grid.linestyle'] = '-'
plt.rcParams['grid.linewidth'] = 0.5
sns.set_style('whitegrid')
from keras.datasets import mnist
from keras.models import Sequential
from keras.layers.core import Dense, Dropout, Activation
from keras.optimizers import Adadelta
from keras.utils import np_utils
from keras.callbacks import Callback

7) If while runnig these import you get error at any library then:
	'pip install missing_library' for windows users
	'sudo apt-get install missing_library' for linux or mac users
	'conda install missing_library' for conda prompt users


-------------------------------------------------------------------------------------------------------------------------------------------
Processing
-------------------------------------------------------------------------------------------------------------------------------------------

8) Total 3 Neural net methods is processesd in ipynb file with changing different hyperparameters 
9) For better continuty and good results data represntation and modification is done with all Neural net's seperately and then processed it into the neural net's.
10) Accuarcy achieved 1) single Hidden MLP = 77.07%
	     	      2) RNN = 85%
	     	      3) DNN = 88.53%
11) Kaggle rank Achieved = 1335
